# Random Topic Generator

A simple command line tool to generate random topics.

## Installation

```bash
pip install random-topic-generator
# random-topic-generator
